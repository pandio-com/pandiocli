from river.neural_net import activations
from river.neural_net.mlp import MLPRegressor

__all__ = ["activations", "MLPRegressor"]