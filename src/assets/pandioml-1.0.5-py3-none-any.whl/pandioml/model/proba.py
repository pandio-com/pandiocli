from river.proba.gaussian import Gaussian
from river.proba.multinomial import Multinomial

__all__ = ["Gaussian", "Multinomial"]